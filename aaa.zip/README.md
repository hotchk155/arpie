arpie
=====

MIDI Arpeggiator

http://www.youtube.com/watch?v=mk7zSJ8mq2A
